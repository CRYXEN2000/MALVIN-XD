/*═════════════════════════════════════════════════════════════*\
|                                                             |
|                  🕸️ 𝕮𝕽𝖄𝕏𝕰𝕹 𝖃 • 𝕯𝖆𝖗𝖐 𝕭𝖔𝖙 𝖂𝖍𝖆𝖙𝖘𝕬𝖕𝖕 🕸️              |
|                                                             |
|  ⚠️ CE FICHIER EST MAUDIT : NE TOUCHE PAS, ÂME MORTELLE ⚠️   |
|─────────────────────────────────────────────────────────────|
| 👑 Propriétaire : 𝙲𝚁𝚈𝚇𝙴𝙽²¹⁰⁹                              |
| ☠️ Contact     : +2250545477175                            |
| 🧠 GitHub      : https://github.com/CRYXEN76                |
| 📺 YouTube     : https://youtube.com/@foden225-i2j          |
| 🩸 Style       : Sombre • Brutal • Infernale                |
\*═════════════════════════════════════════════════════════════*/
const { malvin, commands } = require('../malvin');
const config = require('../settings');
const prefix = config.PREFIX;
const fs = require('fs');
const { getBuffer, getGroupAdmins, getRandom, h2k, isUrl, Json, sleep, fetchJson } = require('../lib/functions2');
const { writeFileSync } = require('fs');
const path = require('path');

malvin({
  pattern: "newgc",
  category: "group",
  desc: "Create a new group and add participants.",
  filename: __filename,
}, async (conn, mek, m, { from, isGroup, body, sender, groupMetadata, participants, reply }) => {
  try {
    if (!body) {
      return reply(`Usage: !newgc group_name;number1,number2,...`);
    }

    const [groupName, numbersString] = body.split(";");
    
    if (!groupName || !numbersString) {
      return reply(`Usage: !newgc group_name;number1,number2,...`);
    }

    const participantNumbers = numbersString.split(",").map(number => `${number.trim()}@s.whatsapp.net`);

    const group = await conn.groupCreate(groupName, participantNumbers);
    console.log('created group with id: ' + group.id); // Use group.id here

    const inviteLink = await conn.groupInviteCode(group.id); // Use group.id to get the invite link

    await conn.sendMessage(group.id, { text: 'hello there' });

    reply(`Group created successfully with invite link: https://chat.whatsapp.com/${inviteLink}\nWelcome message sent.`);
  } catch (e) {
    return reply(`*An error occurred while processing your request.*\n\n_Error:_ ${e.message}`);
  }
});


